# AG DOWNLOAD LINK BOT — বাংলা সেটআপ

## কীভাবে কাজ করে
Telegram-এ বটকে ফাইল পাঠান → `/getlink` → পাবলিক HTTPS লিংক। ব্রাউজার লিংক খুললে ফাইল ডাউনলোড হবে।

## গুরুত্বপূর্ণ সীমা
- Telegram-এর hosted/cloud Bot API দিয়ে `getFile` download সাধারণত সর্বোচ্চ 20 MB।
- Render Free-এর স্থানীয় ফাইল/SQLite স্থায়ী স্টোরেজ নয়। এই কোডে SQLite `/tmp`-এ, তাই রিস্টার্টে লিংকের রেকর্ড হারাতে পারে।
- বড় ফাইল/স্থায়ী স্টোরেজের জন্য object storage বা নিজের Local Bot API Server দরকার।
- কেবল নিজের বা শেয়ার করার অনুমতি আছে এমন ফাইল ব্যবহার করুন।

## ধাপ ১: Telegram bot token
1. Telegram-এ `@BotFather` খুলুন।
2. `/newbot` পাঠান, নাম ও username দিন।
3. BotFather-এর token গোপন রাখুন। কাউকে পাঠাবেন না।

## ধাপ ২: Render-এ deploy
1. GitHub-এ নতুন repository তৈরি করুন, যেমন `AG-DOWNLOAD-LINK-BOT`।
2. `app.py`, `requirements.txt`, `render.yaml` আপলোড করুন।
3. Render-এ New → Blueprint অথবা Web Service দিয়ে repository connect করুন।
4. Environment Variables সেট করুন:
   - `BOT_TOKEN` = BotFather token
   - `PUBLIC_URL` = Render-এর সম্পূর্ণ URL, যেমন `https://your-service.onrender.com` (শেষে `/` নয়)
   - `WEBHOOK_SECRET` = নিজের বানানো দীর্ঘ random string, শুধু অক্ষর/সংখ্যা/underscore/hyphen ব্যবহার করুন
5. Deploy করুন এবং Render service URL খুলে `/health` যোগ করে পরীক্ষা করুন। `{"ok":true,...}` আসা উচিত।

## ধাপ ৩: Telegram webhook চালু
Termux-এ `curl` ইনস্টল করুন:
```bash
pkg update -y
pkg install curl python git -y
```
তারপর নিজের মান বসিয়ে চালান:
```bash
export BOT_TOKEN='BOTFATHER_TOKEN'
export PUBLIC_URL='https://your-service.onrender.com'
export WEBHOOK_SECRET='নিজের_লম্বা_গোপন_স্ট্রিং'
curl -sS -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setWebhook" \
  -d "url=${PUBLIC_URL}/webhook/${WEBHOOK_SECRET}"
```
সফল হলে `"ok":true` দেখাবে। Token/secret কাউকে দেবেন না এবং স্ক্রিনশট শেয়ার করবেন না।

## ধাপ ৪: ব্যবহার
1. নিজের bot খুলে `/start` পাঠান।
2. একটি ছবি/ভিডিও/অডিও/PDF/ZIP বা অন্য ফাইল পাঠান।
3. `/getlink` পাঠান।
4. বটের দেওয়া HTTPS link ব্রাউজারে খুলে পরীক্ষা করুন।

## শুধু Termux-এ লোকাল পরীক্ষা
Render webhook-এর বিকল্প হিসেবে `python app.py` চালালেই webhook নিজে থেকে পাওয়া যাবে না; Telegram-এর জন্য publicly reachable HTTPS URL দরকার। তাই public link-এর জন্য Render বা অন্য public host আবশ্যক।

import os, re, sqlite3, secrets, mimetypes
from urllib.parse import quote
from flask import Flask, request, abort, Response
import requests

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
PUBLIC_URL = os.environ.get("PUBLIC_URL", "").strip().rstrip("/")
WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET", "").strip()
ADMIN_ID = os.environ.get("ADMIN_ID", "").strip()
DB_PATH = os.environ.get("DB_PATH", "/tmp/ag_download_bot.db")
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024  # Telegram cloud Bot API download limit

if not BOT_TOKEN or not PUBLIC_URL or not WEBHOOK_SECRET:
    print("WARNING: Set BOT_TOKEN, PUBLIC_URL and WEBHOOK_SECRET environment variables.")

app = Flask(__name__)
API = f"https://api.telegram.org/bot{BOT_TOKEN}"

def db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS last_files (
        user_id INTEGER PRIMARY KEY, file_id TEXT NOT NULL, file_name TEXT NOT NULL,
        mime_type TEXT, file_size INTEGER, token TEXT NOT NULL UNIQUE
    )""")
    return con

def tg(method, payload=None):
    r = requests.post(f"{API}/{method}", json=payload or {}, timeout=30)
    r.raise_for_status()
    data = r.json()
    if not data.get("ok"):
        raise RuntimeError(data.get("description", "Telegram API error"))
    return data["result"]

def send_message(chat_id, text, reply_markup=None):
    payload = {"chat_id": chat_id, "text": text, "disable_web_page_preview": True}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    tg("sendMessage", payload)

def human_size(n):
    if n is None: return "Unknown"
    units = ["B", "KB", "MB", "GB"]
    value = float(n)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024

def get_file_info(msg):
    # Telegram photos are represented as sizes; choose the largest variant.
    if msg.get("photo"):
        f = max(msg["photo"], key=lambda x: x.get("file_size", 0))
        return f["file_id"], "photo.jpg", "image/jpeg", f.get("file_size")
    for key, default_name, default_mime in [
        ("document", "document.bin", "application/octet-stream"),
        ("video", "video.mp4", "video/mp4"),
        ("audio", "audio.mp3", "audio/mpeg"),
        ("voice", "voice.ogg", "audio/ogg"),
        ("animation", "animation.mp4", "video/mp4"),
        ("video_note", "video-note.mp4", "video/mp4"),
        ("sticker", "sticker.webp", "image/webp"),
    ]:
        obj = msg.get(key)
        if obj:
            name = obj.get("file_name") or default_name
            mime = obj.get("mime_type") or default_mime
            return obj["file_id"], name, mime, obj.get("file_size")
    return None

@app.get("/")
def home():
    return ("AG DOWNLOAD LINK BOT is running. Send a file to your Telegram bot, then send /getlink. "
            "Direct links are limited to files Telegram's cloud Bot API can download (about 20 MB).", 200)

@app.get("/health")
def health():
    return {"ok": True, "service": "AG DOWNLOAD LINK BOT"}

@app.post("/webhook/<secret>")
def webhook(secret):
    if not WEBHOOK_SECRET or not secrets.compare_digest(secret, WEBHOOK_SECRET):
        abort(403)
    update = request.get_json(silent=True) or {}
    msg = update.get("message") or update.get("edited_message")
    if not msg:
        return {"ok": True}
    chat_id = msg.get("chat", {}).get("id")
    user_id = msg.get("from", {}).get("id")
    text = (msg.get("text") or "").strip()

    if text.startswith("/start"):
        send_message(chat_id,
            "👋 AG DOWNLOAD LINK BOT\n\n"
            "১) আগে ছবি/ভিডিও/অডিও/PDF/ZIP বা ফাইল পাঠান।\n"
            "২) তারপর /getlink লিখুন।\n"
            "৩) পাওয়া HTTPS লিংক অন্যদের পাঠাতে পারবেন।\n\n"
            "সীমা: Telegram cloud Bot API দিয়ে সরাসরি ডাউনলোড সাধারণত 20 MB পর্যন্ত।")
        return {"ok": True}

    if text.startswith("/getlink"):
        con = db()
        row = con.execute("SELECT file_name, file_size, token FROM last_files WHERE user_id=?", (user_id,)).fetchone()
        con.close()
        if not row:
            send_message(chat_id, "আগে আমাকে একটি ফাইল পাঠান, তারপর /getlink লিখুন।")
        else:
            name, size, token = row
            link = f"{PUBLIC_URL}/d/{token}"
            send_message(chat_id,
                f"✅ Download link তৈরি হয়েছে!\n\n"
                f"📁 File: {name}\n"
                f"📦 Size: {human_size(size)}\n\n"
                f"🔗 {link}\n\n"
                "নোট: লিংক কাজ করতে এই সার্ভার চালু থাকতে হবে।")
        return {"ok": True}

    info = get_file_info(msg)
    if info:
        file_id, name, mime, size = info
        if size and size > MAX_DOWNLOAD_BYTES:
            send_message(chat_id,
                f"এই ফাইলটি {human_size(size)}। Telegram cloud Bot API দিয়ে সরাসরি ফাইল ডাউনলোডের সীমা প্রায় 20 MB; "
                "এই ফাইলের জন্য আলাদা storage বা Local Bot API Server প্রয়োজন।")
            return {"ok": True}
        token = secrets.token_urlsafe(24)
        con = db()
        con.execute("""INSERT INTO last_files(user_id,file_id,file_name,mime_type,file_size,token)
          VALUES(?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET
          file_id=excluded.file_id,file_name=excluded.file_name,mime_type=excluded.mime_type,
          file_size=excluded.file_size,token=excluded.token""",
          (user_id, file_id, name, mime, size, token))
        con.commit()
        con.close()
        send_message(chat_id, f"📥 ফাইল পেয়েছি: {name}\nএখন /getlink লিখুন।")
    elif text and not text.startswith("/"):
        send_message(chat_id, "ফাইল পাঠান, তারপর /getlink লিখুন।")
    return {"ok": True}

@app.get("/d/<token>")
def download(token):
    con = db()
    row = con.execute("SELECT file_id,file_name,mime_type,file_size FROM last_files WHERE token=?", (token,)).fetchone()
    con.close()
    if not row:
        abort(404, "Link not found. Send the file to the bot again and use /getlink.")
    file_id, name, mime, size = row
    if size and size > MAX_DOWNLOAD_BYTES:
        abort(413, "This file exceeds the Telegram cloud Bot API download limit.")
    try:
        info = tg("getFile", {"file_id": file_id})
        file_path = info["file_path"]
        file_url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}"
        upstream = requests.get(file_url, stream=True, timeout=(15, 120))
        if upstream.status_code != 200:
            abort(502, "Telegram could not provide this file. Please generate a new link.")
        content_type = mime or mimetypes.guess_type(name)[0] or "application/octet-stream"
        safe_name = re.sub(r'[\r\n"]', "_", name)[:180] or "download.bin"
        def generate():
            try:
                for chunk in upstream.iter_content(chunk_size=64 * 1024):
                    if chunk:
                        yield chunk
            finally:
                upstream.close()
        headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quote(safe_name)}",
                   "Cache-Control": "no-store"}
        if size:
            headers["Content-Length"] = str(size)
        return Response(generate(), content_type=content_type, headers=headers, direct_passthrough=True)
    except requests.RequestException:
        abort(502, "Temporary download error. Try again later.")

if __name__ == "__main__":
    # Render provides PORT; local Termux test uses 8080.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8080")))
